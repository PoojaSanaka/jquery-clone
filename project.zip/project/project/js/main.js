$(document).ready(function(e) {
  for (var i=0;i<data.products.length;i++) {
    var productContainer = $('#product').clone();
    console.log(data.products[i].name);
     $(productContainer).attr('id','product'+ (i+1))
    productContainer.find('.f-product__name').html(data.products[i].name);
    productContainer.find('.f-product__description').html(data.products[i].description);
    if(data.products[i].price.was != data.products[i].price.now){
      productContainer.find('.f-product__price--was').html('£'+data.products[i].price.was);
    }
    productContainer.find('.f-product__price--now').html('£'+data.products[i].price.now);
    productContainer.find('.f-product__image').attr('src',data.products[i].image)
    productContainer.insertAfter('#product');
  }
    $('#product').remove();
});
